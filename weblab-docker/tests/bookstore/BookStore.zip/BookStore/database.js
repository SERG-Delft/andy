var books = {}
var authors = {}

function add_author(name) {
    if (name === "") {
        return
    }

    // might want a error for duplicate detection
    // as a fun testing exercise if they detect a pop up
    let max = 0
    for (var id in authors) {
        var author_name = authors[id]
        if (name === author_name) {
            return
        }
        max = id > max ? id : max
    }
    authors[max + 1] = name
}

function add_book(id, name) {
    if (name === "") {
        return
    }

    if (authors[id] == undefined) {
        return
    }
    if (books[id] == undefined) {
        books[id] = []
    }
    // might also want an error for duplicate protection
    for (var book_name of books[id]) {
        if (book_name === name) {
            return
        }
    }
    books[id].push(name)
}

function display_authors(query) {
    // clear current children divs
    var list_div = document.getElementById("author_list")
    list_div.innerHTML = ""  // garbage collection go brrrr

    let author_found = false
    for (var id in authors) {
        var name = authors[id]
        if (!name.includes(query)) {
            continue
        }

        let child = document.createElement("div");
        // using textContent should hopefully not introduce xss
        // using innerHTML however might? might be good to be aware of
        child.textContent = id + " : " + name

        list_div.appendChild(child)

        author_found = true
    }

    if (!author_found) {
        let child = document.createElement("div")
        child.textContent = "No matching authors were found!"

        list_div.append(child)
    }
}

function display_books(query) {
    // clear current children divs
    var list_div = document.getElementById("book_list")
    list_div.innerHTML = ""  // garbage collection go brrrr

    let book_found = false
    for (var id in books) {
        var names = books[id]
        for (var name of names) {
            if (!name.includes(query)) {
                continue
            }

            let child = document.createElement("div");
            child.textContent = "\"" + name + "\" by: " + authors[id]

            list_div.appendChild(child)

            book_found = true
        }
    }

    if (!book_found) {
        let child = document.createElement("div");

        child.textContent = "No matching books were found!"

        list_div.appendChild(child)
    }
}

document.getElementById('author_submit_button').onclick = function () {
    add_author(document.getElementById('author_name').value)
}
document.getElementById('book_submit_button').onclick = function () {
    add_book(parseInt(document.getElementById('author_id').value), document.getElementById('book_name').value)
}

document.getElementById("search_bar").addEventListener("keyup", function(event) {
    if (event.key === "Enter") {
        document.getElementById("search_results").style.visibility = "visible"

        let query = document.getElementById("search_bar").value
        display_books(query)
        display_authors(query)
    }
})

document.getElementById("close_icon").addEventListener("click", function() {
    document.getElementById("search_results").style.visibility = "hidden"
})
